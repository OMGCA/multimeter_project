int mainMenu(void);

void measurementSelection(int rangeOption);

void dataRetrieve(void);

void manualMeasurement(void);

void accessStoredData(void);

