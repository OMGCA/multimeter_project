int readButtonIndex(void);

void ADC1_init(void);

int read_ADC1(void);

void autoRangeSignalInit(void);

void rangeSignal(int a, int b);

void dataLogging(char* displayString, char* unit, char* memArray);

char* dataLogging2(char* displayString, char* unit);

