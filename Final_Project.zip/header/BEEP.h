#ifndef __BEEP_H
#define __BEEP_H

void BEEP_Init (void);

void BEEP_On (void);

void BEEP_Off (void);

void BEEP_Interval (int duration, int interval);

#endif

